// Create an empty array of Int type
let myArray = [Int]()

// Another way to create an empty array
let myArray2 : [Int] = []

// Create an empty array of String type
let myArray3 = [String]()