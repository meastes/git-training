// Create an Array with three elements
var myArray = ["Swift", "Objective-C", "PHP"]
// Loop through Array elements
for arrayElement in myArray {
    print(arrayElement)
